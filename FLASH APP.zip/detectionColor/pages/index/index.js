// index.js
// 获取应用实例
const app = getApp()

Page({
  data: {
    isFlashlight: false,
    width: 0,
    height: 0,
    coordinate: null,
    filePath: ""
  },
  takePhoto() {
    const that = this;
    const ctx = wx.createCameraContext();
    ctx.takePhoto({
      quality: 'high',
      success: (res) => {
        that.setData({
          src: res.tempImagePath
        });

        that.canvas = wx.createCanvasContext("image-canvas", that)
        //过渡页面中，图片的路径坐标和大小
        that.canvas.drawImage(res.tempImagePath, 0, 0, 375, 375)
        wx.showLoading({
          title: '数据处理中',
          mask: true
        })
        that.canvas.setStrokeStyle('white');
        // 这里有一些很神奇的操作,总结就是MD拍出来的照片规格居然不是统一的
        //过渡页面中，对裁剪框的设定
        that.canvas.strokeRect(that.data.gap, 173, 179, 28)
        that.canvas.draw()
        setTimeout(function () {
          wx.canvasToTempFilePath({ //裁剪对参数
            canvasId: "image-canvas",
            x: that.data.gap, //画布x轴起点
            y: 173, //画布y轴起点
            width: 179, //画布宽度
            height: 28, //画布高度
            destWidth: 179, //输出图片宽度
            destHeight: 28, //输出图片高度
            canvasId: 'image-canvas',
            success: function (res) {
              that.filePath = res.tempFilePath;
              that.data.filePath = res.tempFilePath;
              //清除画布上在该矩形区域内的内容。
              that.canvas.clearRect(0, 0, 179, 28)
              that.canvas.drawImage(that.filePath, 0, 0, 179, 28)
              that.canvas.draw(false, () => {
                wx.canvasGetImageData({
                  canvasId: 'image-canvas',
                  x: 0,
                  y: 0,
                  width: 179,
                  height: 28,
                  success(res) {
                    let pixelArr = [];
                    let arr1 = [];
                    res.data.forEach((item, index) => {

                      if (index % 4 == 3 && index !== 0) {
                        pixelArr.push(arr1);
                        arr1 = [];
                      } else {
                        arr1.push(item);
                      }
                    });
                    let axisArr = [];
                    let rowArr = [];
                    pixelArr.forEach((item, index) => {
                      if (rowArr.length === 179) {
                        axisArr.push(rowArr);
                        rowArr = [];
                        rowArr.push({
                          color: item,
                          axi: {
                            endlong: axisArr.length,
                            across: rowArr.length,
                          }
                        })
                      } else {
                        rowArr.push({
                          color: item,
                          axi: {
                            endlong: axisArr.length,
                            across: rowArr.length,
                          }
                        })
                        if (index === (pixelArr.length - 1)) axisArr.push(rowArr);
                      }
                    })

                    let valArr = []; // 得到的结果arr
                    let areaArr = []; // 红色区域arr
                    let lineArr = []; // 红色区域一列arr

                    let centerArr = JSON.parse(JSON.stringify(axisArr[Math.ceil(axisArr.length / 2)]));
                    for (let index = centerArr.length - 1; index >= 0; index--) {
                      let item = centerArr[index];
                      if (!item) {
                        continue;
                      }
                      if (item.color[0] > 120 && item.color[1] > 120 && item.color[2] > 120) {
                        // console.log("白色");
                      } else {
                        console.log("红色");
                        let resultArr = [];
                        let idxArr = [];
                        for (let i = 0; i < 4; i++) {
                          if ((index - i) < 0) {
                            continue;
                          }
                          let theTopTen = centerArr[index - i];
                          if (theTopTen.color[0] > 120 && theTopTen.color[1] > 120 && theTopTen.color[2] > 120) {

                          } else {
                            resultArr.push(theTopTen)
                            idxArr.push(index - i);
                          }
                        }


                        if (resultArr.length == 4) {
                          areaArr.push(resultArr);
                          idxArr.forEach(idxItem => {
                            centerArr.splice(idxItem, 1);
                          });
                        }
                      }
                    }



                    wx.hideLoading();
                    wx.navigateTo({
                      url: `/pages/testing/testing?img=${that.data.filePath}&coordinate=${JSON.stringify(areaArr)}`,
                    });
                  }
                });
              })
              //在此可进行网络请求
            },
            fail: function (e) {
              wx.hideLoading()
              wx.showToast({
                title: '出错啦...',
                icon: 'loading'
              })
            }
          });
        }, 1000);
      }
    })
  },
  error(e) {
    console.log(e.detail)
  },
  onLoad() {
    const that = this;
    wx.getSystemInfo({
      success: function (res) {
        var width = res.windowWidth
        var height = res.windowHeight
        var gap = 98;
        that.setData({
          width,
          height,
          gap
        })
      }
    })
  },
  // 打开关闭闪光灯
  flashlight() {
    const that = this;
    that.setData({
      isFlashlight: !that.data.isFlashlight
    });
  },
  onShareAppMessage() {
    return {
      title: 'FLASH Pen Reader',
      path: '/pages/index/index',
    }
  }
})