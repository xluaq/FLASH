// pages/testing/testing.js
import moment from '../../utils/moment';
Page({

    /**
     * 页面的初始数据
     */
    data: {
        img: "",
        coordinate: [],
        list: [{
            tit: "Invalid",
            ischecked: true,
        }, {
            tit: "Negative",
            ischecked: false,
        }, {
            tit: "Positive",
            ischecked: false,
        }],
        time: "",
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        console.log(options);
        const that = this;

        if (options) {
            let coordinate = JSON.parse(options.coordinate);

            console.log(coordinate);
            let c_x = coordinate.length >= 1 && coordinate.length<3? coordinate[0][1].axi.across:"";
            let t_x = coordinate.length == 2 &&  coordinate[1][1].axi.across;

            let time = moment(new Date()).format("YYYY-MM-DD HH:mm:ss");
            
            that.data.list.forEach(item=>{
                item.ischecked = false
            });
            if(coordinate.length==1){
                that.data.list[1].ischecked = true
            }
            if(coordinate.length==2){
                that.data.list[2].ischecked = true
            }
            if(coordinate.length>2 || coordinate.length==0){
                that.data.list[0].ischecked = true
            }
            that.setData({
                img: options.img,
                coordinate: JSON.parse(options.coordinate),
                time: new Date(),
                c_x,
                t_x,
                time,
                list:that.data.list
            });

            that.setData({});
        }

    },
    goBack() {
        wx.navigateBack({
            delta: 0,
        })
    },
    radioChange(e){
        console.log(e)
    },
    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady: function () {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow: function () {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide: function () {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload: function () {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh: function () {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function () {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})